var US_EAST_VERSION
var US_EAST_MODIFY_DATE
var US_WEST_VERSION
var US_WEST_MODIFY_DATE
var EU_VERSION
var EU_MODIFY_DATE
var APAC_VERSION
var APAC_MODIFY_DATE

var refreshTime = 60*5*1000;

var region = {
    US_EAST: 'us_east',
    US_WEST: 'us_west',
    EU: 'eu',
    APAC: 'apac'
}

function getDateTime(time) {
    console.log(time);
    var today = time ? new Date(time) : new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time + ' GMT+0700 (ICT)';
    return dateTime;
}

function switchTab(event, tab) {
    var i;
    var x = document.getElementsByClassName("tab");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    document.getElementById(tab).style.display = "block";
    tablinks = document.getElementsByName("tablink");
    for (i = 0; i < x.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" w3-blue-grey", "");
    }
    event.currentTarget.className += " w3-blue-grey";
}

function setVersionAndModifyTime(region, version, modify_date) {
    document.getElementById(`${region}_version`).innerHTML = version;
    document.getElementById(`${region}_modify_time`).innerHTML = new Date(modify_date.seconds * 1000);
}

function loadingData() {
    var inputs = document.getElementsByTagName('td');
    for (var i = 0; i < inputs.length; i++) {
        var str = inputs[i].id;
        if (!str)
            continue;

        if (str.match('_version') || str.match('_modify_time').length) {
            inputs[i].innerHTML = 'loading'
        }
    }
}

function getVersionAsync(url) {
    return fetch(url).then(response => response.json())
}

function fetchData(databaseRef) {
    databaseRef.get().then(function (doc) {
        if (doc.exists) {
            documentData = doc.data();
            const { us_east, us_west, eu, apac } = documentData;
            setVersionAndModifyTime(region.APAC, apac.version, apac.modify_date);
            setVersionAndModifyTime(region.US_EAST, us_east.version, us_east.modify_date);
            setVersionAndModifyTime(region.US_WEST, us_west.version, us_west.modify_date);
            setVersionAndModifyTime(region.EU, eu.version, eu.modify_date);
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch(function (error) {
        console.log("Error getting document:", error);
    });
}

function updateProductInfo(regionURL, databaseRef) {
    loadingData();
    fetchData(databaseRef)
    const { US_EAST_URL, US_WEST_URL, EU_URL, APAC_URL } = regionURL;

    databaseRef.get().then(function (doc) {
        if (doc.exists) {
            var documentData = doc.data();
            getVersionAsync(US_EAST_URL)
                .then(data => {
                    const version = data.version || data.Version;
                    if (documentData.us_east.version != version) {
                        setVersionAndModifyTime(region.US_EAST, version, Timestamp.now());
                        databaseRef.update({
                            us_east: {
                                version,
                                modify_date: Timestamp.now()
                            }
                        })
                            .then(function () {
                                console.log("Document successfully updated!");
                            })
                            .catch(function (error) {
                                // The document probably doesn't exist.
                                console.error("Error updating document: ", error);
                            });
                        US_EAST_VERSION = version;
                    }

                })

            getVersionAsync(US_WEST_URL)
                .then(data => {
                    const version = data.version || data.Version;

                    if (documentData.us_west.version != version) {
                        setVersionAndModifyTime(region.US_WEST, version, Timestamp.now());
                        databaseRef.update({
                            us_west: {
                                version,
                                modify_date: Timestamp.now()
                            }
                        })
                            .then(function () {
                                console.log("Document successfully updated!");
                            })
                            .catch(function (error) {
                                // The document probably doesn't exist.
                                console.error("Error updating document: ", error);
                            });
                        US_WEST_VERSION = version;
                    }

                })

            getVersionAsync(EU_URL)
                .then(data => {
                    const version = data.version || data.Version;

                    if (documentData.eu.version != version) {
                        setVersionAndModifyTime(region.EU, version, Timestamp.now());
                        databaseRef.update({
                            eu: {
                                version,
                                modify_date: Timestamp.now()
                            }
                        })
                            .then(function () {
                                console.log("Document successfully updated!");
                            })
                            .catch(function (error) {
                                // The document probably doesn't exist.
                                console.error("Error updating document: ", error);
                            });
                        EU_VERSION = version;
                    }
                })

            getVersionAsync(APAC_URL)
                .then(data => {
                    const version = data.version || data.Version;

                    if (documentData.apac.version != version) {
                        setVersionAndModifyTime(region.APAC, version, Timestamp.now());
                        databaseRef.update({
                            apac: {
                                version,
                                modify_date: Timestamp.now()
                            }
                        })
                            .then(function () {
                                console.log("Document successfully updated!");
                            })
                            .catch(function (error) {
                                // The document probably doesn't exist.
                                console.error("Error updating document: ", error);
                            });
                        APAC_VERSION = version;
                    }
                })
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    })
    .then(() => fetchData(databaseRef))
    .catch(function (error) {
        console.log("Error getting document:", error);
    });
}