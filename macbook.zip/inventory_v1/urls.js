const qtestRegionsURL = {
    US_EAST_URL: 'https://elite.qtestnet.com/version',
    US_WEST_URL: 'https://eliteuswe2.qtestnet.com/version',
    EU_URL: 'https://eliteeu.qtestnet.com/version',
    APAC_URL: 'https://eliteap.qtestnet.com/version'
}

const sessionRegionsURL = {
    US_EAST_URL: 'https://session-js.qtestnet.com/version',
    US_WEST_URL: 'https://session-7.qtestnet.com/version',
    EU_URL: 'https://session-6.qtestnet.com/version',
    APAC_URL: 'https://session-8.qtestnet.com/version'
}

const launchRegionsURL = {
    US_EAST_URL: '',
    US_WEST_URL: '',
    EU_URL: '',
    APAC_URL: ''
}

const insightRegionsURL = {
    US_EAST_URL: 'https://insights-v2.qtestnet.com/version',
    US_WEST_URL: 'https://insights-7.qtestnet.com/version',
    EU_URL: 'https://insights-6.qtestnet.com/version',
    APAC_URL: 'https://insights-8.qtestnet.com/version'
}

const parametersRegionsURL = {
    US_EAST_URL: 'https://parameters.qtestnet.com/version',
    US_WEST_URL: 'https://parameter-7.qtestnet.com/version',
    EU_URL: 'https://parameter-6.qtestnet.com/version',
    APAC_URL: 'https://parameter-8.qtestnet.com/version'
}

const pulseRegionsURL = {
    US_EAST_URL: '',
    US_WEST_URL: '',
    EU_URL: '',
    APAC_URL: ''
}